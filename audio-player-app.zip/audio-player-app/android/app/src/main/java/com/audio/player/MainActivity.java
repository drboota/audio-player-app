package com.audio.player;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
